/*
* Write your implementation of the validate_sensor_data function here.
* Make sure to follow the requirements outlined in the task overview.
*/

#include "status_defines.h"
#include <math.h>

status_t validate_sensor_data(float input, float min, float max, uint8_t *fault_counter) {
    // Write your logic here
}